﻿using PGA;
using System;
using System.Collections;
using System.Diagnostics;
using System.Text;

namespace ConsoleApp1
{
    internal class Program
    {
        private static byte[] v1;
        private static void Main(string[] args)
        {
            try
            {
                System.Threading.Tasks.Task task_hash = new System.Threading.Tasks.Task(Calc_Hash, args[0].ToString());
                task_hash.Start();
                task_hash.Wait();
            }
            catch
            {
                System.Threading.Tasks.Task task_hash = new System.Threading.Tasks.Task(Calc_Hash, null);
                task_hash.Start();
                task_hash.Wait();
            }
        }
        public static void Calc_Hash(object file)
        {
            Stopwatch st = new Stopwatch();

        Console:
            byte shift = 1;

            Console.Clear();
            Console.Title = "MD-Caspian HASH FUNCTION DEVELOPED BY MR. TOURAJ OSTOVARI";
            Console.ForegroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("Write your string:\r\n");
            //
            try
            {

                System.IO.StreamReader streamReader = new System.IO.StreamReader(file.ToString(), Encoding.UTF8);
                //System.IO.StreamReader streamReader = new System.IO.StreamReader(@"C:\Users\Toraj\Downloads\Compressed\Udemy.Deep.dive.into.Windows.Presentation.Foundation.WPF_p30download.com.part5.rar", Encoding.UTF8);

                v1 = Encoding.UTF8.GetBytes(streamReader.ReadToEnd());
                //v1 = Encoding.Unicode.GetChars(System.IO.File.ReadAllBytes(file.ToString()));
            }
            catch
            {
                v1 = Encoding.UTF8.GetBytes(Console.ReadLine());

            }

            //Console.WriteLine("Going to beging");
            //Console.ReadLine();
            st.Start();
            BitArray A = new BitArray(128, true);
            BitArray B = new BitArray(128, true);
            BitArray C = new BitArray(128, true);
            BitArray D = new BitArray(128, true);

            BitArray A_ = new BitArray(128, false);
            BitArray B_ = new BitArray(128, false);
            BitArray C_ = new BitArray(128, false);
            BitArray D_ = new BitArray(128, false);

            int Index = 0;
            bool A_Time = true;
            bool B_Time = false;
            bool C_Time = false;
            bool D_Time = false;
            bool Jump_ = false;
            int Final_Counter = 1;
            string Temp_Append = "";
            long Counter_Index = 0;
            for (; Counter_Index < v1.Length;)
            {
                byte item = v1[Counter_Index++];
                bool IsAppened_ = false;
                if (++shift == 20) shift = 1;
                string Binary = Convert.ToString(item, 2);

                int Index_ = (Binary.Length - 1);
                // Reverse ham dare rokh mide
                if (A_Time)
                {
                    if (Jump_ == true) { Jump_ = false; Index = 0; }
                    while (Index_ >= 0)
                    {
                        if (IsAppened_ == false)
                        {
                            if (Temp_Append.Length == 0)
                            {
                                if (Binary[Index_] == '1')
                                    A.Set(Index, true);
                                else if (Binary[Index_] == '0')
                                    A.Set(Index, false);
                                Index++; Index_--;
                            }
                            else
                            {
                                for (int i = Temp_Append.Length - 1; i >= 0; i--)
                                {
                                    if (Temp_Append[i] == '1') A.Set(Index++, true); else A.Set(Index++, false);
                                }
                                Temp_Append = "";
                            }
                        }
                        else if (IsAppened_ == true)
                        {
                            if (Binary[Index_] == '1')
                                Temp_Append += "1";
                            else if (Binary[Index_] == '0')
                                Temp_Append += "0";
                            Index_--;

                        }
                        if (Index == 127)
                        {
                            A_Time = false;
                            B_Time = true;
                            Index = 0;
                            Jump_ = true;
                            if (Index_ >= 0)
                            {
                                IsAppened_ = true;
                            }
                        }
                    }
                }
                else if (B_Time)
                {
                    if (Jump_ == true) { Jump_ = false; Index = 0; }
                    while (Index_ >= 0)
                    {
                        if (IsAppened_ == false)
                        {
                            if (Temp_Append.Length == 0)
                            {
                                if (Binary[Index_] == '1')
                                    B.Set(Index, true);
                                else if (Binary[Index_] == '0')
                                    B.Set(Index, false);
                                Index++; Index_--;
                            }
                            else
                            {
                                for (int i = Temp_Append.Length - 1; i >= 0; i--)
                                {
                                    if (Temp_Append[i] == '1') B.Set(Index++, true); else B.Set(Index++, false);
                                }
                                Temp_Append = "";
                            }
                        }
                        else if (IsAppened_ == true)
                        {
                            if (Binary[Index_] == '1')
                                Temp_Append += "1";
                            else if (Binary[Index_] == '0')
                                Temp_Append += "0";
                            Index_--;

                        }
                        if (Index == 127)
                        {
                            B_Time = false;
                            C_Time = true;
                            Index = 0;
                            Jump_ = true;
                            if (Index_ >= 0)
                            {
                                IsAppened_ = true;
                            }
                        }
                    }
                }
                else if (C_Time)
                {
                    if (Jump_ == true) { Jump_ = false; Index = 0; }
                    while (Index_ >= 0)
                    {
                        if (IsAppened_ == false)
                        {
                            if (Temp_Append.Length == 0)
                            {
                                if (Binary[Index_] == '1')
                                    C.Set(Index, true);
                                else if (Binary[Index_] == '0')
                                    C.Set(Index, false);
                                Index++; Index_--;
                            }
                            else
                            {
                                for (int i = Temp_Append.Length - 1; i >= 0; i--)
                                {
                                    if (Temp_Append[i] == '1') C.Set(Index++, true); else C.Set(Index++, false);
                                }
                                Temp_Append = "";
                            }
                        }
                        else if (IsAppened_ == true)
                        {
                            if (Binary[Index_] == '1')
                                Temp_Append += "1";
                            else if (Binary[Index_] == '0')
                                Temp_Append += "0";
                            Index_--;

                        }
                        if (Index == 127)
                        {
                            C_Time = false;
                            D_Time = true;
                            Index = 0;
                            Jump_ = true;
                            if (Index_ >= 0)
                            {
                                IsAppened_ = true;
                            }
                        }
                    }
                }
                else if (D_Time)
                {
                    if (Jump_ == true) { Jump_ = false; Index = 0; }

                    while (Index_ >= 0)
                    {
                        if (IsAppened_ == false)
                        {
                            if (Temp_Append.Length == 0)
                            {
                                if (Binary[Index_] == '1')
                                    D.Set(Index, true);
                                else if (Binary[Index_] == '0')
                                    D.Set(Index, false);
                                Index++; Index_--;
                            }
                            else
                            {
                                for (int i = Temp_Append.Length - 1; i >= 0; i--)
                                {
                                    if (Temp_Append[i] == '1') D.Set(Index++, true); else D.Set(Index++, false);
                                }
                                Temp_Append = "";
                            }
                        }
                        else if (IsAppened_ == true)
                        {
                            if (Binary[Index_] == '1')
                                Temp_Append += "1";
                            else if (Binary[Index_] == '0')
                                Temp_Append += "0";
                            Index_--;

                        }
                        if (Index == 127)
                        {
                            A_Time = true;
                            D_Time = false;
                            Index = 0;
                            Jump_ = true;
                            if (Index_ >= 0)
                            {
                                IsAppened_ = true;
                            }
                            Final_Counter++;
                        }
                    }
                }
                if (Final_Counter == 1600) break;
            }
            for (int i = 1; i <= 80; i++)
            {
                BEL.lst.Length = 128;
                BEL.BEL(v1.Length * i, shift + i, 127);
                A_ = A_.Xor(BEL.lst);
                BEL.BEL((long)Math.Pow(v1.Length, i), shift * i, 127);
                A_ = A_.Xor(BEL.lst); 
                BEL.BEL((long)(Math.Pow(v1.Length, i)*50), ((shift * i)*50), 127);
                A_ = A_.And(BEL.lst).Not();

                A = A.Xor(A_).LeftShift(shift);
                B = B.Xor(A);
                C = C.Xor(B);
                D = D.Xor(C);
                A_ = ((BitArray)D.Clone());
                B_ = ((BitArray)A.Clone());
                C_ = ((BitArray)B.Clone());
                D_ = ((BitArray)C.Clone());

            }

            A_ = B_.Xor(A_);
            A_ = C_.And(A_).Not();
            A_ = D_.And(A_).Not();
            string result = "";
            Console.WriteLine($"Hash:");
            for (int i = 0; i < A_.Count; i++)
            {
                if (A_.Get(i))
                {
                    result += "1";
                }
                else
                {
                    result += "0";
                }
                if (result.Length == 4)
                {
                    Console.Write(Convert.ToInt32(result, 2).ToString("X"));
                    result = "";
                }
            }
            st.Stop();
            Console.ForegroundColor = ConsoleColor.Red;

            Console.WriteLine("\nStopwatch:" + st.Elapsed);
            Console.ReadLine();
            file = null;
            BEL.lst.SetAll(false);
            goto Console;
        }
    }
}
